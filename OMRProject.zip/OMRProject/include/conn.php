<?php


$conn = mysqli_connect("localhost" , "root" , "" , "OMREvaluator");
//for($i=1;$i<=40;$i++){
//$sql = "INSERT INTO `answers` (`question_no`, `answer`) VALUES ('".$i."', '0');";
//mysqli_query($conn , $sql);
//}

?>