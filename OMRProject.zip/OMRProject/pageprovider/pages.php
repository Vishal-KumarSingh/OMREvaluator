<?php
function setanswers(){
    include "../view/modalanswerset.php";
}
function merit_list(){
    include "../view/merit_list.php";
}
function manage_candidates(){
    include "../view/manage_candidate.php";
}
function start_scanning(){
    include "../view/start_scanning.php";
}
function settings(){
    include "../view/settings.php";
}
function top_twenty(){
    include "../view/top_twenty.php";
}
?>  